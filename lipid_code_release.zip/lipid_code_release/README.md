# Lipid-interface code and structural audit

Curated release candidate, 7 September 2026. Scope: lipid-interface calculations
supporting Fig. 2b and Supplementary Fig. S4. This is not a complete NADPH
electronic-structure or NEB release. No repository or DOI has yet been assigned.

## Contents and quick check

- `audit_release.py`: newly added, read-only offline verification of the supplied
  geometries, stored classification metrics and illustrative Fig. 2b sums.
- `source_protocols/`: three unmodified source snapshots: final v2 hydrated
  construction/relaxation, MGDG force/connectivity classification, and TiO2 dry
  perturbation tests. These depend on Matlantis and the original workspace layout;
  they are not portable one-command reproduction scripts.
- `structures/`: all 54 reported lipid-interface structures, including rejected
  cases, identified by the `run_id` in the original result table.
- `reference/`: three slabs and two gas-phase lipid references.
- `verification/`: six additional MGDG/TiO2 dry perturbation structures.
- `data/`: five original CSV tables, preserved byte-for-byte. Read the correction
  below before using their legacy flags or panel letters.
- `MANIFEST.sha256`: file integrity hashes, excluding the manifest itself.

With Python and NumPy installed, run from any directory:

```text
python /path/to/lipid_code_release/audit_release.py
```

The audit needs no network, PFP access or VASP. It does not recalculate energies
or forces. It prints the audit results without editing any source data.

Expected: 54 main structures and six verification structures checked; 26 intact
PC and one rearranged PC; MGDG classifications of 20 rearranged, six insufficient
contact and one borderline, using the force values already in the MGDG manifest.
No PC per-structure force table is present, so this audit does not independently
establish the reported 26/27 PC force-converged admissibility count.

## Classification used in this audit

Connectivity is compared against the corresponding supplied gas-phase reference,
preserving lipid atom identity and ordering. Element-pair distance thresholds (Å):

```text
C-C 1.75   C-O 1.65   C-N 1.65   C-H 1.30   O-H 1.25
N-H 1.25   O-P 1.80   O-O 1.45   C-P 1.95
```

As in the final source scripts, distances are Cartesian distances in the supplied
cell, without minimum-image wrapping. A connectivity change is a diagnostic
flag, not proof of a particular reaction mechanism in a native membrane.

`d_min` is the minimum lipid–slab distance; `n_contact` counts lipid atoms whose
nearest slab atom is less than 3.5 Å away. The ordered classification is:

1. Missing force: unverified; never assumed converged.
2. `fmax >= 0.03 eV/Å`: invalid (not converged).
3. Changed lipid connectivity: invalid (bond rearrangement).
4. `d_min >= 3.0 Å`: invalid (detached), a label for this geometric criterion.
5. `n_contact < 3`: borderline (single-site contact), the source label covering
   insufficient multisite contact.
6. Otherwise: valid under these criteria.

Force convergence is a force-tolerance test, not a global-minimum or local-minimum
proof. Optimiser step counts alone do not establish convergence. The stored MGDG
forces were computed with the fixed-bottom constraints in `mgdg_package.py`.
The separate `azim090` verification case has fmax 1.3704 eV/Å and is not converged.

The v2 simulation's preliminary `state` uses an OR contact rule. It is not the
final `quant_status`. Do not use `state == contact` as the sole admissibility test.

## Energy and illustrative conversion

The column named `W_adi` is a signed energy difference:

```text
DeltaE = E_system - E_separately_relaxed_slab - E_separately_relaxed_lipid_water_cluster
```

Negative values indicate favourable binding relative to these model references.
The positive separation-energy magnitude is `-DeltaE`, not the signed `DeltaE`.
For negative DeltaE only, the reported equivalent-tension conversion is:

```text
sigma = (-DeltaE / A) * (1 + cos(theta_c)) / 2
A = 0.65 nm^2; theta_c = 90 degrees
sigma [mN/m] = -DeltaE [eV] * 123.24  (reported rounded conversion factor)
```

Do not apply an unconditional absolute value to a positive DeltaE. Energy values
for rearranged models remain diagnostic and are not intact-lipid adhesion values.
`E_int` uses frozen slab and adlayer references; `E_form` is the frozen-adlayer
formation energy relative to separate gas-phase lipid and water. They are not
interchangeable with `W_adi`.

Fig. 2b is the illustrative dry sum `0.32*sigma_PC + 0.17*sigma_MGDG`, reproducing
104.8, 103.6 and 92.0 mN/m for Cu, Cu2O and TiO2. The audit uses the recorded
table precision, including one-decimal PC dry values. The composition proxies
derive from reported fatty-acid weight percentages, not measured membrane area
fractions: Block et al., J. Biol. Chem. 258, 13281–13286 (1983),
doi:10.1016/S0021-9258(17)44113-5. These sums include diagnostic MGDG terms and
are not quantitative predictions of native membrane tension or rupture.

## Original-table correction and figure identifiers

`data/interfacial_water_v2_FINAL.csv` marks `TiO2_MGDG_0W_dry` as
`quant_valid=True`. This is a superseded OR-rule result. The final MGDG manifest
and the offline audit classify it as borderline (d_min 2.89 Å, n_contact 1).
The corresponding legacy flag in `FigS4_manifest.csv` must likewise not be used
as the final admissibility decision. Original files are retained unchanged so the
discrepancy remains visible, not silently rewritten.

`FigS4_manifest.csv` contains the historical a–r sub-image labels and PNG names.
PNG renderings are deliberately not duplicated in this code package. Use
`run_id`, surface, lipid and water count to locate the included VASP structure.
In the revised six-panel figure: a/c/e are PC on Cu/Cu2O/TiO2; b/d/f are MGDG on
the same surfaces. Each panel shows dry/1-water/3-water configurations left to right.

## Simulation dependencies and limits

The retained source scripts explicitly request PFP v8.0.0 with `PBE_PLUS_D3`
and `PFVM_D3_PFVM`, using ASE and the Matlantis API. Access to PFP through
Matlantis requires the provider's licence; no model weights, credentials or
proprietary software are included. Installing NumPy alone runs the offline audit,
not the simulations. The original README reported Python 3.11 and
pfp-api-client 2.5.0; exact runtime versions of ASE/NumPy and the provider client
still need confirmation from the calculation environment.

The source snapshots retain their original `~/Yeom` paths. Executing them can
launch paid calculations and write to that workspace. Inspect and configure
them before use. They have been syntax-checked, not executed during curation.

Missing for full from-scratch reproduction: the final dry orientation-scan
executed configurations/logs for all three surfaces, separated relaxed reference
energies/geometries underlying the final dry `W_adi` values, the PC final-force
table, and original runtime dependency records. Hydrated construction can be
inspected in `interfacial_water_v2.py`; its initial displacements are 0.5/1/1.5/2 Å,
followed by water-only and then constrained-slab relaxation.

The four gaps are alternative starting configurations, not experimental replicates.
Neither convergence nor a rendering establishes a global minimum or native lipid
chemistry. Truncation-related rearrangement remains a model limitation.

## Before public deposit

Confirm the listed missing provenance, resolve legacy flags in an explicitly
versioned derived table if needed, and approve authorship and an appropriate
code/data licence. No licence is assigned by this curation step. Add the actual
repository/DOI only after deposit. The draft statement is scoped to the materials
actually included; it must not be used to claim a complete NADPH pipeline release.
