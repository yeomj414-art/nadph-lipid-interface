# Draft for use after deposit and author approval

Custom Python code for lipid–surface configuration generation and structural
classification, together with the corresponding relaxed structures, result tables
and an offline verification script, is available at [repository DOI]. The deposited
source snapshots and their reproduction limits are documented in the repository.
Atomistic calculations used PFP v8.0.0 through Matlantis with the PBE_PLUS_D3 and
PFVM_D3_PFVM settings. Access to PFP is subject to the provider's commercial
licensing terms; the proprietary potential is not redistributed.

Do not paste this statement as a claim of existing availability before the DOI
and the authors' sharing/licence decisions are confirmed. This package covers
lipid-interface work only. A statement covering the complete manuscript requires
the actual final NADPH analysis code, not the excluded generic templates.
