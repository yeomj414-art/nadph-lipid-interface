# -*- coding: utf-8 -*-
"""MGDG / TiO2(101) / dry 의 단일점 약흡착이 안정한 최소점인지 확인한다.

배경: d_min = 2.89 A 이지만 n_contact = 1. 원자 하나만 닿은 상태다.
     결과를 보고 판정 기준을 조이는 것은 선택적 제외이므로, 대신 이 상태가
     실제 최소점인지 직접 시험한다.

시험
  (1) 가장 가까운 원자쌍이 무엇인지 확인
  (2) 지질을 +0.5, +1.0 A 올려 다시 이완 -> d_min 이 2.89 A 부근으로 되돌아오는가
  (3) 방위각을 90, 180, 270 deg 돌려 다시 이완 -> 같은 약흡착 최소점이 재현되는가

되돌아오면: 안정한 약흡착 최소점 -> 36.2 mN/m 를 제한적으로 사용 가능
멀어지면 : 실제로는 탈착 -> borderline 유지
"""
import os
import numpy as np
from ase.io import read, write
from ase.constraints import FixAtoms
from ase.optimize import LBFGS
from pfp_api_client.pfp.estimator import Estimator, EstimatorCalcMode, EstimatorMethodType
from pfp_api_client.pfp.calculators.ase_calculator import ASECalculator

HOME = os.path.expanduser("~/Yeom")
OUT = os.path.join(HOME, "mgdg_tio2_check"); os.makedirs(OUT, exist_ok=True)
K, FMAX, NLIP, FIX = 123.24, 0.03, 39, 3.0
RC = {("C","C"):1.75,("C","O"):1.65,("C","H"):1.30,("O","H"):1.25,
      ("H","C"):1.30,("H","O"):1.25,("O","C"):1.65,("O","O"):1.45}


def calc():
    return ASECalculator(Estimator(calc_mode=EstimatorCalcMode.PBE_PLUS_D3,
                                   method_type=EstimatorMethodType.PFVM_D3_PFVM,
                                   model_version="v8.0.0"))
def sp(a):
    b = a.copy(); b.pbc = True; b.calc = calc(); return b.get_potential_energy()

def relax(a, fix=None, steps=900):
    b = a.copy(); b.pbc = True
    if fix is not None:
        z = b.get_positions()[:, 2]
        b.set_constraint(FixAtoms(indices=[i for i in range(len(b)) if z[i] < z.min()+fix]))
    b.calc = calc()
    o = LBFGS(b, logfile=None); o.run(fmax=FMAX, steps=steps)
    return b, b.get_potential_energy(), o.get_number_of_steps()

def bs(m):
    s = m.get_chemical_symbols(); x = m.get_positions()
    D = np.linalg.norm(x[:,None,:]-x[None,:,:], axis=2)
    return {(i,j) for i in range(len(s)) for j in range(i+1,len(s))
            if RC.get((s[i],s[j])) and D[i,j] < RC[(s[i],s[j])]}

def geom(a, n):
    p = a.get_positions(); s = a.get_chemical_symbols()
    D = np.linalg.norm(p[:n][:,None,:] - p[n:][None,:,:], axis=2)
    i, j = np.unravel_index(D.argmin(), D.shape)
    return (float(D.min()), int((D.min(0) < 3.5).sum()),
            "%s%d(slab)-%s%d(lipid)" % (s[i], i, s[n+j], j))

base = os.path.join(HOME, "lipid_TiO2")
slab = read(os.path.join(base, "TiO2_slab.vasp")); n = len(slab)
E_slab = relax(slab, FIX)[1]
ref = read(os.path.join(HOME, "lipid_Cu111", "gasrelax_MGDG.vasp"))
REF = bs(ref)
E_lip = relax(ref)[1]

a0 = read(os.path.join(base, "adopted_MGDG_vacuum.vasp"))
d0, n0, pair0 = geom(a0, n)
print("(1) 원본 구조")
print("    d_min = %.2f A, n_contact = %d" % (d0, n0))
print("    가장 가까운 쌍: %s\n" % pair0, flush=True)

print("%-18s %8s %6s %6s %11s %8s %-11s %s"
      % ("case", "d_min", "n_con", "steps", "W_adi(eV)", "sigma", "integrity", "pair"), flush=True)
print("-" * 96, flush=True)

def run(tag, atoms):
    rel, E, ns = relax(atoms, FIX)
    d, nc, pair = geom(rel, n)
    ad = rel[n:]; ad.cell = rel.cell
    W = E - E_slab - relax(ad)[1]
    b = bs(rel[n:n+NLIP])
    ok = not ((REF - b) or (b - REF))
    write(os.path.join(OUT, "%s.vasp" % tag), rel)
    print("%-18s %8.2f %6d %6d %11.4f %8.1f %-11s %s"
          % (tag, d, nc, ns, W, abs(W)*K if W < 0 else float("nan"),
             "intact" if ok else "rearranged", pair), flush=True)
    return d, nc, W

run("original", a0)
# (2) 들어올렸다가 되돌아오는가
for lift in (0.5, 1.0):
    a = a0.copy(); p = a.get_positions()
    p[n:n+NLIP, 2] += lift; a.set_positions(p)
    run("lift+%.1fA" % lift, a)
# (3) 방위각 회전
for az in (90, 180, 270):
    a = a0.copy()
    m = a[n:n+NLIP]
    m.rotate(az, "z", center=m.get_center_of_mass())
    b = a[:n] + m; b.cell = a.cell
    run("azim%03d" % az, b)

print("\n판정 기준")
print("  d_min 이 2.7-3.1 A 로 되돌아오고 n_contact 가 유지되면 -> 안정한 약흡착 최소점")
print("  d_min > 3.5 A 로 멀어지면 -> 실제 탈착, borderline 유지")
