# -*- coding: utf-8 -*-
"""계면 물 재계산 v2 — 초기 간격 스윕 + 2단계 이완 + 접촉/비접촉 모두 기록.

v1 의 결함: 지질을 3.0-3.6 A 들어올린 뒤 물을 넣었더니 지질이 내려오지 않고
그 자리에 머물렀다. PC 8/16, MGDG 14/16 이 접촉원자 0개 (표면에서 3.6-5.5 A).
접착에너지를 계산한 게 아니라 떠 있는 계를 계산했다.

**접촉한 것만 사후 선별하면 선택 편향이다.** 떠 있는 것이 최적화 정체인지
실제 탈착인지 구분해야 한다. 그래서:

  1) 건조 최적화 구조에서 시작
  2) 초기 간격을 0.5 / 1.0 / 1.5 / 2.0 A 로 스윕 (3-3.6 A 는 쓰지 않는다)
  3) 물은 표면-헤드그룹 사이의 **실제 빈 공간**에 넣는다
     (여유 > 2.6 A 이고 위를 덮는 지질원자 >= 3 인 지점 중 가장 넓은 곳)
  4) 1단계: 슬랩+지질 고정하고 물만 짧게 이완 -> 2단계: 풀고 전체 이완
  5) 접촉/비접촉을 **모두 기록**한다. 조성이 같으므로 조건 안에서 E_sys 직접 비교 가능
  6) 판정은 사후 분석에서:
       - 가까운 초기값은 접촉, 먼 초기값만 뜸  -> 초기배치에 의한 국소최소점
       - 여러 초기값에서 비접촉이 반복적으로 더 낮은 E_sys -> 실제 탈착
  7) QC: d_min, 접촉원자수, 물-표면거리, 물-지질 H결합, 구조 무결성

보고는 W_adi (흡착층을 클러스터로 떼는 일). E_ads 는 물-지질 결합이 섞이므로 쓰지 않는다.
"""
import os, time, itertools
import numpy as np
import pandas as pd
from ase.io import read, write
from ase.build import molecule
from ase.constraints import FixAtoms
from ase.optimize import LBFGS
from pfp_api_client.pfp.estimator import Estimator, EstimatorCalcMode, EstimatorMethodType
from pfp_api_client.pfp.calculators.ase_calculator import ASECalculator

HOME = os.path.expanduser("~/Yeom")
OUT = os.path.join(HOME, "iw_v2"); os.makedirs(OUT, exist_ok=True)
CSV = os.path.join(OUT, "iw_v2.csv")
K, FMAX = 123.24, 0.03
GAPS = [0.5, 1.0, 1.5, 2.0]
NL = {"PC": 47, "MGDG": 39}
SURF = {"Cu111": dict(d="lipid_Cu111", slab="Cu111_slab.vasp", fix=4.0),
        "Cu2O":  dict(d="lipid_Cu2O",  slab="Cu2O_slab.vasp",  fix=3.0),
        "TiO2":  dict(d="lipid_TiO2",  slab="TiO2_slab.vasp",  fix=3.0)}
RCOV = {("C","C"):1.75,("C","O"):1.65,("C","N"):1.65,("C","H"):1.30,("O","H"):1.25,
        ("N","H"):1.25,("O","P"):1.80,("P","O"):1.80,("H","C"):1.30,("H","O"):1.25,
        ("H","N"):1.25,("N","C"):1.65,("O","C"):1.65,("O","O"):1.45,("P","C"):1.95,("C","P"):1.95}


def calc():
    return ASECalculator(Estimator(calc_mode=EstimatorCalcMode.PBE_PLUS_D3,
                                   method_type=EstimatorMethodType.PFVM_D3_PFVM,
                                   model_version="v8.0.0"))

def sp(a):
    b = a.copy(); b.pbc = True; b.calc = calc(); return b.get_potential_energy()

def bondset(m):
    s = m.get_chemical_symbols(); x = m.get_positions()
    D = np.linalg.norm(x[:, None, :] - x[None, :, :], axis=2)
    return {(i, j) for i in range(len(s)) for j in range(i+1, len(s))
            if RCOV.get((s[i], s[j])) and D[i, j] < RCOV[(s[i], s[j])]}


def place_in_void(a, n_slab, nlip, nw, rng):
    """표면-헤드그룹 사이의 실제 빈 공간에 물을 넣는다. 못 넣으면 None."""
    lip = np.arange(n_slab, n_slab + nlip)
    cur = a.copy()
    p0 = a.get_positions()
    ztop = p0[:n_slab, 2].max()
    lip_xy = p0[lip, :2]; cen = lip_xy.mean(0)
    for _ in range(nw):
        cand = []
        P = cur.get_positions()
        for _t in range(6000):
            j = rng.integers(len(lip))
            xy = lip_xy[j] + rng.normal(0, 1.0, 2)
            if np.linalg.norm(xy - cen) > 6.0:
                continue
            z = rng.uniform(ztop + 2.0, ztop + 3.2)
            c = np.array([xy[0], xy[1], z])
            clear = float(np.linalg.norm(P - c, axis=1).min())
            if clear <= 2.6:
                continue
            dxy = np.linalg.norm(p0[lip][:, :2] - c[:2], axis=1)
            cover = int(sum(1 for k, jj in enumerate(lip) if dxy[k] < 3.0 and p0[jj, 2] > z))
            if cover >= 3:
                cand.append((clear, c))
        if not cand:
            return None
        cand.sort(key=lambda t: -t[0])          # 가장 넓은 빈 공간
        c = cand[0][1]
        wm = molecule("H2O")
        wm.rotate(rng.uniform(0, 360), rng.normal(size=3), center="COM")
        wm.positions += c - wm.get_center_of_mass()
        cur += wm
    cur.pbc = True
    return cur


def two_stage(init, n_slab, nlip, fix):
    """1단계 물만 이완 -> 2단계 전체 이완."""
    b = init.copy(); b.pbc = True
    b.set_constraint(FixAtoms(indices=list(range(n_slab + nlip))))
    b.calc = calc()
    LBFGS(b, logfile=None).run(fmax=0.15, steps=150)
    z = b.get_positions()[:, 2]
    b.set_constraint(FixAtoms(indices=[i for i in range(len(b)) if z[i] < z.min() + fix]))
    o = LBFGS(b, logfile=None); o.run(fmax=FMAX, steps=900)
    return b, b.get_potential_energy(), o.get_number_of_steps()


def qc(a, n_slab, nlip, refbonds):
    p = a.get_positions(); s = a.get_chemical_symbols()
    ztop = p[:n_slab, 2].max()
    lip = list(range(n_slab, n_slab + nlip)); wat = list(range(n_slab + nlip, len(a)))
    D = np.linalg.norm(p[:n_slab][:, None, :] - p[lip][None, :, :], axis=2)
    dmin = float(D.min()); ncon = int((D.min(0) < 3.5).sum())
    pol = [i for i in lip if s[i] in ("O", "N", "P")]
    ws = []
    for k in range(len(wat) // 3):
        o = wat[3*k]
        dxy = np.linalg.norm(p[lip][:, :2] - p[o, :2], axis=1)
        cov = int(sum(1 for kk, j in enumerate(lip) if dxy[kk] < 3.0 and p[j, 2] > p[o, 2]))
        ds = float(np.linalg.norm(p[:n_slab] - p[o], axis=1).min())
        hb = int(sum(1 for j in pol if np.linalg.norm(p[j] - p[o]) < 3.5))
        ws.append((round(float(p[o, 2]-ztop), 2), round(ds, 2), cov, hb))
    b = bondset(a[n_slab:n_slab+nlip])
    intact = not ((refbonds - b) or (b - refbonds))
    state = "contact" if (dmin < 3.0 or ncon >= 3) else ("detached" if dmin > 3.5 else "border")
    return dict(d_min=round(dmin, 2), n_contact=ncon, state=state,
                intact=intact, water=str(ws))


rows = []
if os.path.exists(CSV):
    rows = pd.read_csv(CSV).to_dict("records")
done = {(r["surf"], r["lipid"], r["nw"], r["gap"]) for r in rows}

GAS, REF = {}, {}
for lp in ("PC", "MGDG"):
    g = read(os.path.join(HOME, "lipid_Cu111", "gasrelax_%s.vasp" % lp))
    GAS[lp] = sp(g); REF[lp] = bondset(g)
_w = molecule("H2O"); _w.cell = read(os.path.join(HOME, "lipid_Cu111", "Cu111_slab.vasp")).cell
E_H2O = sp(_w)

ESLAB = {}
for su, c in SURF.items():
    sl = read(os.path.join(HOME, c["d"], c["slab"]))
    b = sl.copy(); b.pbc = True
    z = b.get_positions()[:, 2]
    b.set_constraint(FixAtoms(indices=[i for i in range(len(b)) if z[i] < z.min()+c["fix"]]))
    b.calc = calc(); LBFGS(b, logfile=None).run(fmax=FMAX, steps=600)
    ESLAB[su] = b.get_potential_energy()
print("참조 준비 완료. E(H2O)=%.4f\n" % E_H2O, flush=True)

print("%-6s %-5s %2s %5s | %10s %9s %8s %5s %-9s %s"
      % ("surf", "lip", "n", "gap", "E_sys", "W_adi", "s(W)", "dmin", "state", "물"), flush=True)
print("-" * 120, flush=True)

for lp in ("PC", "MGDG"):
    for su, nw, gap in itertools.product(("Cu111", "Cu2O", "TiO2"), (1, 3), GAPS):
        if (su, lp, nw, gap) in done:
            continue
        c = SURF[su]; base = os.path.join(HOME, c["d"])
        dryf = os.path.join(base, "adopted_%s_vacuum.vasp" % lp)
        if not os.path.exists(dryf):
            continue
        n_slab = len(read(os.path.join(base, c["slab"]))); nlip = NL[lp]
        tag = "%s_%s_%dW_g%.1f" % (su, lp, nw, gap)
        f = os.path.join(OUT, "v2_%s.vasp" % tag)
        t0 = time.time()
        try:
            if os.path.exists(f):
                rel = read(f); E_sys = sp(rel); ns = -1
            else:
                a = read(dryf); p = a.get_positions()
                p[n_slab:n_slab+nlip, 2] += gap
                a.set_positions(p)
                rng = np.random.default_rng(int(gap*10))
                init = place_in_void(a, n_slab, nlip, nw, rng)
                if init is None:
                    print("%-6s %-5s %2d %5.1f | 빈 공간 없음" % (su, lp, nw, gap), flush=True)
                    continue
                rel, E_sys, ns = two_stage(init, n_slab, nlip, c["fix"])
                write(f, rel)
            E_slab_fro = sp(rel[:n_slab])
            ad = rel[n_slab:]; ad.cell = rel.cell
            E_ad_fro = sp(ad)
            adr = ad.copy(); adr.pbc = True; adr.calc = calc()
            LBFGS(adr, logfile=None).run(fmax=FMAX, steps=600)
            E_ad_rel = adr.get_potential_energy()
            W = E_sys - ESLAB[su] - E_ad_rel
            Ei = E_sys - E_slab_fro - E_ad_fro
            Ef = E_ad_fro - GAS[lp] - nw*E_H2O
            q = qc(rel, n_slab, nlip, REF[lp])
            rows.append(dict(surf=su, lipid=lp, nw=nw, gap=gap, E_sys=E_sys,
                             W_adi=W, E_int=Ei, E_form=Ef,
                             s_W=(abs(W)*K if W < 0 else np.nan), unfav=(W > 0),
                             steps=ns, sec=round(time.time()-t0), **q))
            pd.DataFrame(rows).to_csv(CSV, index=False)
            print("%-6s %-5s %2d %5.1f | %10.4f %9.4f %8s %5.2f %-9s %s%s (%.0fs)"
                  % (su, lp, nw, gap, E_sys, W,
                     "%.1f" % (abs(W)*K) if W < 0 else "불리", q["d_min"], q["state"],
                     q["water"], "" if q["intact"] else " REARR", time.time()-t0), flush=True)
        except Exception as e:
            print("%-6s %-5s %2d %5.1f | FAILED %s" % (su, lp, nw, gap, str(e)[:50]), flush=True)

df = pd.DataFrame(rows)
if len(df):
    print("\n=== 조건별 판정 (E_sys 는 조성이 같아 조건 안에서 직접 비교 가능) ===", flush=True)
    for (su, lp, nw), g in df.groupby(["surf", "lipid", "nw"]):
        g = g.sort_values("gap")
        emin = g.E_sys.min()
        print("  %-6s %-5s %dH2O" % (su, lp, nw), flush=True)
        for _, r in g.iterrows():
            print("    gap %.1f  dE_sys %+.3f eV  %-9s dmin %.2f  n_con %2d  %s"
                  % (r.gap, r.E_sys - emin, r.state, r.d_min, r.n_contact,
                     "W=%.1f" % r.s_W if r.W_adi < 0 else "흡착 불리"), flush=True)
        con = g[g.state == "contact"]; det = g[g.state == "detached"]
        if len(con) and len(det):
            v = "비접촉이 더 낮음 -> 실제 탈착 가능성" if det.E_sys.min() < con.E_sys.min() \
                else "접촉이 더 낮음 -> 비접촉은 국소최소점(초기배치 인공물)"
            print("    판정: %s (dE = %+.3f eV)"
                  % (v, det.E_sys.min() - con.E_sys.min()), flush=True)
