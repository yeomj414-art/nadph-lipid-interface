# -*- coding: utf-8 -*-
"""MGDG 전용 패키지.

구성
  structures/   MGDG 27개 (수화 24 + 건조 3) vasp + png
  verification/ TiO2 dry 최소점 검증 6개 vasp + png
  MGDG_manifest.csv  3단계 분류 + 실측 fmax

판정은 스텝 수가 아니라 **최종 구조의 fmax** 로 한다.
  converged             fmax < 0.03 eV/A  (이완 기준과 동일)
  geometric_contact     d_min < 3.0 A
  robust_multisite      n_contact >= 3
  quant_status          valid / borderline / invalid
"""
import os, glob, shutil, zipfile
import numpy as np
import pandas as pd
from ase.io import read, write
from ase.constraints import FixAtoms
from pfp_api_client.pfp.estimator import Estimator, EstimatorCalcMode, EstimatorMethodType
from pfp_api_client.pfp.calculators.ase_calculator import ASECalculator

HOME = os.path.expanduser("~/Yeom")
OUT = os.path.join(HOME, "MGDG_pkg")
for s in ("structures", "verification"):
    os.makedirs(os.path.join(OUT, s), exist_ok=True)
K, FMAX, NLIP = 123.24, 0.03, 39
NS = {"Cu111": 320, "Cu2O": 288, "TiO2": 288}
FIX = {"Cu111": 4.0, "Cu2O": 3.0, "TiO2": 3.0}
RC = {("C","C"):1.75,("C","O"):1.65,("C","H"):1.30,("O","H"):1.25,
      ("H","C"):1.30,("H","O"):1.25,("O","C"):1.65,("O","O"):1.45}


def calc():
    return ASECalculator(Estimator(calc_mode=EstimatorCalcMode.PBE_PLUS_D3,
                                   method_type=EstimatorMethodType.PFVM_D3_PFVM,
                                   model_version="v8.0.0"))

def bs(m):
    s = m.get_chemical_symbols(); x = m.get_positions()
    D = np.linalg.norm(x[:,None,:]-x[None,:,:], axis=2)
    return {(i,j) for i in range(len(s)) for j in range(i+1,len(s))
            if RC.get((s[i],s[j])) and D[i,j] < RC[(s[i],s[j])]}

REF = bs(read(os.path.join(HOME, "lipid_Cu111", "gasrelax_MGDG.vasp")))

def analyse(path, surf):
    a = read(path); a.pbc = True; n = NS[surf]
    z = a.get_positions()[:,2]
    a.set_constraint(FixAtoms(indices=[i for i in range(len(a)) if z[i] < z.min()+FIX[surf]]))
    a.calc = calc()
    F = np.linalg.norm(a.get_forces(), axis=1)
    p = a.get_positions(); s = a.get_chemical_symbols()
    D = np.linalg.norm(p[:n][:,None,:] - p[n:n+NLIP][None,:,:], axis=2)
    i, j = np.unravel_index(D.argmin(), D.shape)
    b = bs(a[n:n+NLIP])
    br, fo = REF - b, b - REF
    return dict(fmax_eV_A=round(float(F.max()), 4),
                converged=bool(F.max() < FMAX),
                d_min_A=round(float(D.min()), 2),
                n_contact=int((D.min(0) < 3.5).sum()),
                closest_pair="%s%d(slab)-%s%d(lipid)" % (s[i], i, s[n+j], j),
                integrity=("intact" if not (br or fo) else "rearranged"),
                bonds_broken=len(br), bonds_formed=len(fo))

# ---- 구조 수집 ----
src = []
for f in sorted(glob.glob(os.path.join(HOME, "iw_v2", "v2_*MGDG*.vasp"))):
    b = os.path.basename(f)[3:-5]                       # Cu111_MGDG_1W_g0.5
    su, _, nwt, g = b.split("_")
    src.append((f, "%s_MGDG_%s_%s.vasp" % (su, nwt, g), su, int(nwt[0]), float(g[1:]), "hydrated"))
for su, d in (("Cu111","lipid_Cu111"), ("Cu2O","lipid_Cu2O"), ("TiO2","lipid_TiO2")):
    f = os.path.join(HOME, d, "adopted_MGDG_vacuum.vasp")
    if os.path.exists(f):
        src.append((f, "%s_MGDG_0W_dry.vasp" % su, su, 0, np.nan, "dry"))

W = pd.read_csv(os.path.join(HOME, "iw_v2", "iw_v2.csv"))
DRYW = {"Cu111": -0.5731, "Cu2O": -0.7158, "TiO2": -0.2935}

rows = []
for f, name, su, nw, gap, kind in src:
    shutil.copy(f, os.path.join(OUT, "structures", name))
    q = analyse(f, su)
    if kind == "dry":
        w = DRYW[su]
    else:
        m = W[(W.surf==su)&(W.lipid=="MGDG")&(W.nw==nw)&(np.isclose(W.gap, gap))]
        w = float(m.W_adi.iloc[0]) if len(m) else np.nan
    geo = q["d_min_A"] < 3.0
    multi = q["n_contact"] >= 3
    if not q["converged"]:
        status = "invalid (not converged)"
    elif q["integrity"] == "rearranged":
        status = "invalid (bond rearrangement)"
    elif not geo:
        status = "invalid (detached)"
    elif not multi:
        status = "borderline (single-site contact)"
    else:
        status = "valid"
    rows.append(dict(file=name, surface=su, n_water=nw, initial_gap_A=gap,
                     W_adi_eV=w, sigma_mN_m=(round(abs(w)*K,1) if w == w and w < 0 else np.nan),
                     geometric_contact=geo, robust_multisite_contact=multi,
                     quant_status=status, **q))

# ---- 검증 6개 ----
V = []
for f in sorted(glob.glob(os.path.join(HOME, "mgdg_tio2_check", "*.vasp"))):
    name = os.path.basename(f)
    shutil.copy(f, os.path.join(OUT, "verification", name))
    q = analyse(f, "TiO2")
    V.append(dict(file=name, case=name[:-5], **q))

for d in ("structures", "verification"):
    for f in sorted(glob.glob(os.path.join(OUT, d, "*.vasp"))):
        p = f.replace(".vasp", ".png")
        if not os.path.exists(p):
            write(p, read(f), rotation="-90x", show_unit_cell=0, scale=14)

M = pd.DataFrame(rows).sort_values(["surface","n_water","initial_gap_A"], na_position="first")
M.to_csv(os.path.join(OUT, "MGDG_manifest.csv"), index=False, encoding="utf-8")
pd.DataFrame(V).to_csv(os.path.join(OUT, "MGDG_TiO2_dry_verification.csv"),
                       index=False, encoding="utf-8")

open(os.path.join(OUT, "README.txt"), "w", encoding="utf-8").write("""MGDG package
============
structures/    27 relaxed MGDG structures (24 hydrated + 3 dry), vasp + png
verification/  6 runs probing the TiO2 dry minimum, vasp + png
MGDG_manifest.csv                  one row per structure
MGDG_TiO2_dry_verification.csv     the 6 verification runs

Convergence is judged from the recomputed force on the final structure
(fmax_eV_A, threshold 0.03 eV/A), not from optimiser step counts.
Step counts cannot distinguish a converged run from one that hit the
iteration limit, and a zero-step run means the force criterion was already
met - i.e. a stationary point - not that nothing happened.

quant_status
  valid                            converged, intact, d_min < 3.0 A, n_contact >= 3
  borderline (single-site contact)  converged and intact but only one contact atom
  invalid (bond rearrangement)      covalent bond list differs from the relaxed gas-phase reference
  invalid (detached)                d_min >= 3.0 A
  invalid (not converged)           fmax >= 0.03 eV/A; W_adi from such a run is not meaningful

TiO2 / dry
  Converged local minimum at d_min 2.89 A (fmax 0.028), single-site contact
  via a surface O...H-C pair, sigma = 36.2 mN/m.  Upward displacements of
  0.5 and 1.0 A relax to distinct shallower converged minima at 3.40 and
  3.92 A (25.7 and 18.0 mN/m), so this is a flat region containing several
  weak minima rather than one well-defined adsorbed state.  Azimuthal
  rotations of 180 and 270 deg converge to rearranged structures; the 90 deg
  run did not converge (fmax 1.37) and its W_adi is excluded.
  Recorded as borderline and kept out of the primary quantitative comparison.

The rearrangement seen on Cu(111) and Cu2O(111) may be an artifact of
truncating the acyl chains to acetyl groups and should not be presented as
native membrane chemistry.
""")

zp = os.path.join(HOME, "MGDG_pkg.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for r, _, fs in os.walk(OUT):
        for f in sorted(fs):
            full = os.path.join(r, f)
            z.write(full, os.path.relpath(full, os.path.dirname(OUT)))

print(M[["file","W_adi_eV","sigma_mN_m","fmax_eV_A","converged","d_min_A",
         "n_contact","integrity","quant_status"]].to_string(index=False))
print()
print(M.quant_status.value_counts().to_string())
print("\n-> %s (%.0f KB)" % (zp, os.path.getsize(zp)/1024))
