"""Offline release audit, added during curation; not the original simulation driver.

Run: python audit_release.py
Requires NumPy only. Reads files; does not modify data, launch PFP or infer forces.
Distances reproduce the original non-minimum-image Cartesian classifiers.
The VASP reader deliberately supports only the supplied VASP5 files.
"""
from pathlib import Path
import csv
import json
from collections import Counter
import numpy as np

ROOT = Path(__file__).resolve().parent
N_SLAB = {"Cu111": 320, "Cu2O": 288, "TiO2": 288}
CUTOFFS = {"C-C":1.75, "C-O":1.65, "C-N":1.65, "C-H":1.30,
           "O-H":1.25, "N-H":1.25, "O-P":1.80, "O-O":1.45, "C-P":1.95}
RC = {tuple(sorted(k.split('-'))): v for k,v in CUTOFFS.items()}

def table(name):
    with (ROOT / 'data' / name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def structure(path):
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    scale = [float(x) for x in lines[1].split()]
    if len(scale)!=1 or scale[0]<=0:
        raise ValueError(f'Unsupported scale: {path}')
    cell = np.array([[float(x) for x in l.split()] for l in lines[2:5]]) * scale[0]
    elements = lines[5].split()
    counts = [int(x) for x in lines[6].split()]
    symbols = [s for s,n in zip(elements,counts) for _ in range(n)]
    i=7
    if lines[i].lower().startswith('s'): i+=1
    mode=lines[i].strip().lower(); i+=1
    xyz=np.array([[float(x) for x in l.split()[:3]] for l in lines[i:i+sum(counts)]])
    assert len(xyz)==len(symbols)
    if mode.startswith('d'): xyz=xyz @ cell
    elif mode.startswith(('c','k')): xyz=xyz * scale[0]
    else: raise ValueError(f'Unsupported coordinates: {path}')
    return symbols, xyz

def bonds(symbols, xyz):
    return {(i,j) for i in range(len(symbols)) for j in range(i+1,len(symbols))
            if np.linalg.norm(xyz[i]-xyz[j]) < RC.get(tuple(sorted((symbols[i],symbols[j]))),0)}

def geometry(path, surface, lipid):
    ref_s, ref_x = structure(ROOT/'reference'/f'gasrelax_{lipid}.vasp')
    s,x=structure(path); n=N_SLAB[surface]; nl=len(ref_s)
    assert s[n:n+nl]==ref_s, f'Atom ordering mismatch: {path}'
    distances=np.linalg.norm(x[:n,None,:]-x[None,n:n+nl,:],axis=2)
    old,new=bonds(ref_s,ref_x),bonds(s[n:n+nl],x[n:n+nl])
    return dict(d_min_A=float(distances.min()), n_contact=int((distances.min(0)<3.5).sum()),
                integrity='rearranged' if old!=new else 'intact',
                bonds_broken=len(old-new), bonds_formed=len(new-old))

def quant_status(q, fmax):
    # Same precedence as source_protocols/mgdg_package.py. Unknown is not pass.
    if fmax is None or not np.isfinite(fmax): return 'unverified (force unavailable)'
    if fmax>=0.03: return 'invalid (not converged)'
    if q['integrity']=='rearranged': return 'invalid (bond rearrangement)'
    if q['d_min_A']>=3.0: return 'invalid (detached)'
    if q['n_contact']<3: return 'borderline (single-site contact)'
    return 'valid'

def equivalent_tension(delta_e):
    # Preserve the reported rounded factor. Positive signed energies are NOT abs-converted.
    return -delta_e*123.24 if delta_e<0 else None

def main():
    rows=table('interfacial_water_v2_FINAL.csv')
    mgdg={r['file']:r for r in table('MGDG_manifest.csv')}
    assert len(rows)==54 and len({r['run_id'] for r in rows})==54
    assert len(mgdg)==27
    discrepancies=[]; statuses=Counter(); geometry_counts=Counter()
    for r in rows:
        filename=r['run_id']+'.vasp'
        q=geometry(ROOT/'structures'/filename,r['surface'],r['lipid'])
        assert q['integrity']==r['integrity'].lower(), filename
        if r['d_min_A']: assert abs(q['d_min_A']-float(r['d_min_A']))<=0.011, filename
        if r['n_contact']: assert q['n_contact']==int(float(r['n_contact'])), filename
        geometry_counts[(r['lipid'],q['integrity'])]+=1
        # Raw tables are preserved byte-for-byte, including the outdated dry-MGDG flag.
        if r['lipid']=='MGDG':
            m=mgdg[filename]
            assert q['n_contact']==int(m['n_contact']), filename
            assert q['bonds_broken']==int(m['bonds_broken']), filename
            assert q['bonds_formed']==int(m['bonds_formed']), filename
            status=quant_status(q,float(m['fmax_eV_A']))
            assert status==m['quant_status'], (filename,status,m['quant_status'])
            statuses[status]+=1
            if (r['quant_valid'].lower()=='true') != (status=='valid'):
                discrepancies.append({'run_id':r['run_id'],'source_flag':r['quant_valid'],
                                      'audited_status':status})
        converted=equivalent_tension(float(r['W_adi_eV']))
        if converted is not None and r['sigma_mN_m']:
            assert abs(converted-float(r['sigma_mN_m']))<=0.051, filename
    verification=table('MGDG_TiO2_dry_verification.csv')
    assert len(verification)==6
    for r in verification:
        q=geometry(ROOT/'verification'/r['file'],'TiO2','MGDG')
        assert q['integrity']==r['integrity'] and q['n_contact']==int(r['n_contact'])
        assert abs(q['d_min_A']-float(r['d_min_A']))<=0.011
    totals={}
    for su in N_SLAB:
        dry={r['lipid']:r for r in rows if r['surface']==su and r['n_water']=='0'}
        # Use source-table displayed values, as in the author's supplied figure.
        totals[su]=round(.32*float(dry['PC']['sigma_mN_m'])+.17*float(dry['MGDG']['sigma_mN_m']),1)
    assert totals=={'Cu111':104.8,'Cu2O':103.6,'TiO2':92.0}
    assert statuses=={'invalid (bond rearrangement)':20,'invalid (detached)':6,
                     'borderline (single-site contact)':1}
    print(json.dumps(dict(structures_checked=54,verification_structures_checked=6,
                         geometry_counts={f'{k[0]} / {k[1]}':v for k,v in geometry_counts.items()},
                         MGDG_status_using_reported_fmax=dict(statuses),
                         raw_table_discrepancies=discrepancies,
                         illustrative_Fig2b_totals_mN_m=totals,
                         not_tested=['PFP forces and energies','PC force convergence',
                                     'original dry orientation selection','NADPH pipeline']),indent=2))

if __name__=='__main__': main()
